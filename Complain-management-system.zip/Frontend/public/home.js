// src/home.js

document.addEventListener('DOMContentLoaded', () => {
  const btnFoto = document.getElementById('btnFoto');

  if (btnFoto) {
    btnFoto.addEventListener('click', () => {
      alert('Navigasi ke fitur Buat Laporan Foto');
    });
  }

});
